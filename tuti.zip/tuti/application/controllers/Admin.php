<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Model_tuti');
	}
	public function index()
	{
		$data['barang'] = $this->Model_tuti->get()->result();;
		$this->load->view('template/header');
		$this->load->view('template/sidebar');
		$this->load->view('dashboard', $data);
		$this->load->view('template/footer');
	}

	public function tambah() {
		$this->load->view('template/header');
		$this->load->view('template/sidebar');
		$this->load->view('tambah');
		$this->load->view('template/footer');
	}

	public function proses_tambah() {
		$nama_produk = $this->input->post('nama_produk');
        $keterangan = $this->input->post('keterangan');
        $kategori_produk = $this->input->post('kategori_produk');
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');

		$data = array(
            'nama_produk' => $nama_produk,
            'keterangan' => $keterangan,
            'kategori_produk' => $kategori_produk,
            'harga' => $harga,
            'stok' => $stok,
        );

        $this->Model_tuti->input_data($data, 'db_barang');
        redirect('admin');
	}
	public function edit($id) {
        $where = array('id_barang' => $id);
        $data['barang'] = $this->Model_tuti->edit_data($where, 'db_barang')->result();
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('edit', $data);
        $this->load->view('template/footer');
    }

	public function update() {
        $id = $this->input->post('id_barang');
        $nama_produk = $this->input->post('nama_produk');
        $keterangan = $this->input->post('keterangan');
        $kategori_produk = $this->input->post('kategori_produk');
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');
        

        $data = array(
            'nama_produk' => $nama_produk,
            'keterangan' => $keterangan,
            'kategori_produk' => $kategori_produk,
            'harga' => $harga,
            'stok' => $stok
        );

        $where = array(
            'id_barang' => $id
        );

        $this->Model_tuti->update_data($where, $data, 'db_barang');
        redirect('admin');
    }

    public function hapus($id) {
        $where = array('id_barang' => $id);
        $this->Model_tuti->hapus_data($where, 'db_barang');
        redirect('admin');
    }
}
