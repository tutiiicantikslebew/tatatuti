<?php

class Hello_tuti extends CI_controller {
public function index () {
$this->load->model('t_tuti');
$data['siswibece']= $this->t_tuti->get_data();

$this->load->view('tu_ti', $data);
}

}

?>