<?php 

class T_tuti extends CI_Model {
public function get_data {

}
}


