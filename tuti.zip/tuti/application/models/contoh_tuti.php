<?php 

class Contoh_tuti extends CI_model {
public function get_data()
{

}
}

 ?>