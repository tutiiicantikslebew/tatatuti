<?php 

class T_tuti extends CI_Model {
public function get_data ()
{
return $this->db->get('biodatadiri')->result_array();
}
}


