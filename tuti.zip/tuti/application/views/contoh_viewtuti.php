<!DOCTYPE html>
<html>
<head>
<title>Contoh view tuti</title>
</head>
<body>

<h1>Contoh View Pada Codeigneter</h1>
<hr>
<p>i think mie ayam, dimsum mentai, bakso, mie koclok, will make me feel better</p>
</body>
</html>