<!-- partial -->
<div class="main-panel">
  <div class="content-wrapper">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Data barang</h4>
        <a href="<?php echo base_url();?>index.php/Admin/tambah" class="btn btn-sm btn-primary mb-2">Tambah</a>
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Keterangan</th>
                <th>Kategori</th>
                <th>Harga</th>
                <th>Stok</th>
                <th colspan="2">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $no = 1;
              foreach ($barang as $brg) : ?>
                <tr>
                  <td><?php echo $no++; ?></td>
                  <td><?php echo $brg->nama_produk; ?></td>
                  <td><?php echo $brg->keterangan; ?></td>
                  <td><?php echo $brg->kategori_produk; ?></td>
                  <td><?php echo $brg->harga; ?></td>
                  <td><?php echo $brg->stok; ?></td>
                  
                  <td onclick="javascript: return confirm('Anda yakin hapus')"><?php echo anchor('admin/hapus/' . $brg->id_barang, '<div class="btn btn-danger btn-sm"><i class="mdi mdi-oar"></i></div>') ?></td>
                            <td><?php echo anchor('admin/edit/' . $brg->id_barang, '<div class="btn btn-primary btn-sm"><i class="mdi mdi-grease-pencil"></i></div>') ?></td>
                <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- content-wrapper ends -->
<!-- partial:partials/_footer.html -->