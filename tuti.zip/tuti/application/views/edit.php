<div class="main-panel">
    <div class="content-wrapper">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Edit Data Barang</h4>
                <?php foreach ($barang as $brg) : ?>
                    <form class="forms-sample" method="POST" action="<?php echo base_url('index.php/Admin/update'); ?>">
                        <div class="form-group">
                            <input type="hidden" class="form-control" id="id_barang" name="id_barang" value="<?php echo $brg->id_barang; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="nama_produk">Nama Produk</label>
                            <input type="text" class="form-control" id="nama_produk" name="nama_produk" value="<?php echo $brg->nama_produk; ?>">
                        </div>
                        <div class="form-group">
                            <label for="keterangan">Keterangan</label>
                            <textarea class="form-control" id="keterangan" name="keterangan" rows="4"><?php echo $brg->keterangan; ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="kategori_produk">Kategori Produk</label>
                            <input type="text" class="form-control" id="kategori_produk" name="kategori_produk" value="<?php echo $brg->kategori_produk; ?>">
                        </div>
                        <div class="form-group">
                            <label for="harga">Harga</label>
                            <input type="number" class="form-control" id="harga" name="harga" value="<?php echo $brg->harga; ?>">
                        </div>
                        <div class="form-group">
                            <label for="stok">Stok</label>
                            <input type="number" class="form-control" id="stok" name="stok" value="<?php echo $brg->stok; ?>">
                        </div>
                        <button type="submit" class="btn btn-primary mr-2">Simpan Perubahan</button>
                        <a href="<?php echo base_url('index.php/kelola_produk'); ?>" class="btn btn-light">Batal</a>
                    </form>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>