<!-- partial -->
<div class="main-panel">
  <div class="content-wrapper">
  
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Form tambah data</h4>
        <form action="<?php echo base_url('index.php/Admin/proses_tambah');?>" method="post">
  <div class="form-group">
    <label for="exampleInputEmail1">Nama Produk</label>
    <input type="text" class="form-control" name="nama_produk">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Keterangan</label>
    <input type="text" class="form-control" name="keterangan">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Kategori</label>
    <input type="text" class="form-control" name="kategori_produk">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Stok</label>
    <input type="text" class="form-control" name="stok">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Harga</label>
    <input type="text" class="form-control" name="harga">
  </div>
  <button type="submit" class="btn btn-primary">Tambah</button>
</form>
        </div>
    </div>

  </div>
</div>
<!-- content-wrapper ends -->
<!-- partial:partials/_footer.html -->













