<!DOCTYPE html>
<html>
<head>
    <title>Daftar Siswi Pplg 1</title>
</head>
<body>

<table border="1px solid black">

<tr>
<th>NAMA LENGKAP</th>
<th>JENIS KELAMIN</th>
<th>TANGGAL LAHIR</th>
<th>ALAMAT</th>
<th>HOBI</th>
</tr>

<?php foreach ($siswibece as $sbc) : ?>

<tr>
<td><?php echo $sbc['NamaLengkap']; ?></td>
<td><?php echo $sbc['JenisKelamin']; ?></td>
<td><?php echo $sbc['TanggalLahir']; ?></td>
<td><?php echo $sbc['Alamat']; ?></td>
<td><?php echo $sbc['Hobi']; ?></td>
</tr>

<?php endforeach; ?>


</table>

</body>
</html>